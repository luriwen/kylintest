#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#define NSPEED	115200
#define NBIT	8
#define BUFLEN	10

int fd1;
int fd2;
/************************************************************************************
 * tty_open_port() open the tty port
 ************************************************************************************
 */
 
int tty_open_port(const char *dev_name)
{
 
	int fd; /* File descriptor for the port */
	fd = open(dev_name, O_RDWR | O_NOCTTY | O_NDELAY);
	if (-1 == fd) {
		perror("open_port: Unable to open tty " );
		exit(1);
	}
	else {
		printf("The %s is opened \n",dev_name);
	}
	/*
	if( (val=fcntl(fd, F_SETFL, 0))< 0)
	perror("fcntl failed");
	*/
	if ( isatty(fd) == 0 )
		perror("This is not a tty device ");

	return (fd);
}

/************************************************************************************
 * tty_set_port() set the attributes of the tty
 ************************************************************************************
 */
int tty_set_port (int fd, int nSpeed, int nBits, char nEvent, int nStop)
{
	struct termios new_ios,old_ios;

	if (tcgetattr(fd, &new_ios) != 0)
		perror("Save the terminal error");

	bzero(&old_ios, sizeof(struct termios));
	old_ios=new_ios;

	tcflush(fd,TCIOFLUSH);
	new_ios.c_cflag |= CLOCAL | CREAD;
	new_ios.c_cflag &= ~CSIZE;

	switch (nBits) {
	case 5:
		new_ios.c_cflag |= CS5;
		break;
	case 6:
		new_ios.c_cflag |= CS6;
		break;
	case 7:
		new_ios.c_cflag |=CS7;
		break;
	case 8:
		new_ios.c_cflag |= CS8;
		break;
	default:
		perror("Wrong  nBits");
		break;
	}

	switch (nSpeed) {
	case 2400:
		cfsetispeed(&new_ios, B2400);
		cfsetospeed(&new_ios, B2400);
		break;
	case 4800:
		cfsetispeed(&new_ios, B4800);
		cfsetospeed(&new_ios, B4800);
		break;
	case 9600:
		cfsetispeed(&new_ios, B9600);
		cfsetospeed(&new_ios, B9600);
		break;
	case 19200:
		cfsetispeed(&new_ios, B19200);
		cfsetospeed(&new_ios, B19200);
		break;
	case 115200:
		cfsetispeed(&new_ios, B115200);
		cfsetospeed(&new_ios, B115200);
		break;
	case 460800:
		cfsetispeed(&new_ios, B460800);
		cfsetospeed(&new_ios, B460800);
		break;
	default:
		perror("Wrong nSpeed\n");
		break;
	}

	switch (nEvent) {
	case 'o':
	case 'O':
		new_ios.c_cflag |= PARENB;
		new_ios.c_cflag |= PARODD;
		new_ios.c_iflag |= (INPCK | ISTRIP);
		break;
	case 'e':
	case 'E':
		new_ios.c_iflag |= (INPCK | ISTRIP);
		new_ios.c_cflag |= PARENB;
		new_ios.c_cflag &= ~PARODD;
		break;
	case 'n':
	case 'N':
		new_ios.c_cflag &= ~PARENB;
		new_ios.c_iflag &= ~INPCK;
		break;
	default:
		perror("Wrong nEvent\n");
		break;
	}

	if (nStop == 1)
		new_ios.c_cflag &= ~CSTOPB ;
	else if (nStop == 2)
		new_ios.c_cflag |= CSTOPB ;

	/* No hardware control */
	new_ios.c_cflag &= ~CRTSCTS;
	/* No software control */
	new_ios.c_iflag &= ~(IXON | IXOFF | IXANY);
	/* delay time set */
	new_ios.c_cc[VTIME] = 0;
	new_ios.c_cc[VMIN] = 0;

	/* raw model */
	new_ios.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	new_ios.c_oflag &= ~OPOST;
 
	new_ios.c_iflag &= ~(INLCR | IGNCR | ICRNL);
	new_ios.c_iflag &= ~(ONLCR | OCRNL);
 
	new_ios.c_oflag &= ~(INLCR | IGNCR | ICRNL);
	new_ios.c_oflag &= ~(ONLCR | OCRNL);
 
 
	tcflush(fd, TCIOFLUSH);
	if (tcsetattr(fd, TCSANOW, &new_ios) != 0) {
		perror("Set the terminal error");
		tcsetattr(fd, TCSANOW, &old_ios);
		return -1;
	}

	return 0;
}

int tty_set(char *dev_name, int nspeed, int nbit)
{
	int fd;
	int nset;

	fd = tty_open_port(dev_name);
	if (fd == -1)
		exit(1);
	printf("open %s success !\n", dev_name);

	nset = tty_set_port(fd, nspeed, nbit, 'O', 1);
	if (nset == -1)
		exit(1);
	printf("set tty %s success !\n", dev_name);

	return fd;	
}

int tty_trans(int fd1, int fd2, char *buf1, char *buf2)
{
	int nread, nwrite;
	int wait_time;

	memset(buf2, 0, BUFLEN);
	nwrite = write(fd1, buf1, BUFLEN);

	nread = 0;
	wait_time = 0;
	while (nread < BUFLEN) {
		nread += read(fd2, buf2 + nread, BUFLEN - nread);
		if (nread < BUFLEN) {
			usleep(1000);
			wait_time ++;
			if (wait_time > 100)
				break;
		}
	}
	if (strncmp(buf1, buf2, BUFLEN))
		return 1;
	else
		return 0;
}

void exit_tty(int signal)
{
	printf("\033[?25h");

	close(fd1);
	close(fd2);

	exit(0);
}

int main(int argc, char **argv)
{
	int ret;
	int wait_time = 0;
	int loop;
	int errloop;
	int hours, mins, secs;
	int argv3;
	struct timeval tvstart, tvend, tvsub;

	char buf1[BUFLEN] = {"987654321"};
	char buf2[BUFLEN] = {"123456789"};
	pid_t fpid;

	argv3 = atoi(argv[3]);

	if (argc < 4) {
		printf("Usage: ./com /dev/ttySx /dev/ttySy time\n");
		exit(1);
	}

	fd1 = tty_set(argv[1], NSPEED, NBIT);
	if (strcmp(argv[1], argv[2]))
		fd2 = tty_set(argv[2], NSPEED, NBIT);
	else
		fd2 = fd1;

	signal(SIGINT, exit_tty);
	gettimeofday(&tvstart, NULL);
	loop = 0;
	errloop = 0;
	if (!strcmp(argv[1], argv[2])) {
		while (1)
		{
			ret = tty_trans(fd1, fd2, buf1, buf2);
			if (ret) {
				errloop ++;
				printf("\nread error!!!!!!! %s in loop %d\n", buf2, loop);
			}

			loop++;

			gettimeofday(&tvend, NULL);
			timersub(&tvend, &tvstart, &tvsub);
			secs = tvsub.tv_sec % 60;
			mins = (tvsub.tv_sec / 60) % 60;
			hours = (tvsub.tv_sec / 60) / 60;

			if ((tvsub.tv_sec / 60) >= argv3) { 
				printf("\033[?25h");
				printf("\n");
				close(fd1);
				close(fd2);
				return 0;
			}
			printf("\033[?25l");
			printf("\rTest Time: %dhours %dmins %dsecs", hours, mins, secs);
		}
	}
	else {
		fpid = fork();
		if (fpid < 0) {
			printf("error in fork !\n");
			exit(1);
		}
			if (fpid == 0) {
				while (1) {
					ret = tty_trans(fd1, fd2, buf1, buf2);
					if (ret) {
						errloop ++;
						printf("\nread error! %s in loop %d pid = %d\n", buf2, loop, fpid);
					}

					loop ++;

					gettimeofday(&tvend, NULL);
					timersub(&tvend, &tvstart, &tvsub);

					if ((tvsub.tv_sec / 60) >= argv3) {
						printf("\033[?25h");
						printf("\n");
						close(fd1);
						close(fd2);
						return 0;
					}
					
				}
				exit(0);
			}
			else {
				while (1) {
					ret = tty_trans(fd2, fd1, buf2, buf1);
					if (ret) {
						errloop ++;
						printf("\nread error! %s in loop %d pid = %d\n", buf1, loop, fpid);
					}

					loop ++;
				
					gettimeofday(&tvend, NULL);
					timersub(&tvend, &tvstart, &tvsub);
					secs = tvsub.tv_sec % 60;
					mins = (tvsub.tv_sec / 60) % 60;
					hours = (tvsub.tv_sec / 60) / 60;

					if ((tvsub.tv_sec / 60) >= argv3) {
						printf("\033[?25h");
						printf("\n");
						close(fd1);
						close(fd2);
						return 0;
					}

					printf("\033[?25l");
					printf("\rTest Time: %dhours %dmins %dsecs", hours, mins, secs);
				}
			}
	}

	close(fd1);
	close(fd2);
	return 0;
}
